#!/bin/python3.11

import subprocess

subprocess.run('ls -la', shell=True)

